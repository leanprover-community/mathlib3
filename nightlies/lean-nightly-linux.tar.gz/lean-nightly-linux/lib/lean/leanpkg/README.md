# leanpkg

`leanpkg` is the package manager for the [Lean theorem prover](https://leanprover.github.io). For more information, see [the reference](https://leanprover.github.io/reference/using_lean.html#using-the-package-manager) or `leanpkg help`.
